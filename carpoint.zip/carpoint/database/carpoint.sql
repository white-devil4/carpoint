-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 02, 2019 at 04:22 PM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carpoint`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE `activity` (
  `ac_id` int(4) NOT NULL,
  `ac_nm` varchar(200) NOT NULL,
  `ac_time` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`ac_id`, `ac_nm`, `ac_time`) VALUES
(51, '2 Booked With 10000', '1564755561'),
(52, 'nitin rathod  Cancellled his booking', '1564755604'),
(53, 'you have new message <a href=\"contact_manage.php\">View</a>', '1564755637');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `a_id` int(4) NOT NULL,
  `a_unm` varchar(6) NOT NULL,
  `a_pwd` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`a_id`, `a_unm`, `a_pwd`) VALUES
(3, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `b_id` int(4) NOT NULL,
  `b_bookid` varchar(100) NOT NULL,
  `b_vehicle` varchar(20) NOT NULL,
  `b_unm` varchar(20) NOT NULL,
  `b_day` int(20) NOT NULL,
  `b_amt` int(40) NOT NULL,
  `b_sdate` varchar(40) NOT NULL,
  `b_edate` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`b_id`, `b_bookid`, `b_vehicle`, `b_unm`, `b_day`, `b_amt`, `b_sdate`, `b_edate`) VALUES
(13, 'BKID8570078', '37', '13', 2, 10000, '20-08-2019', '22-08-2019');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `b_id` int(4) NOT NULL,
  `b_nm` varchar(30) NOT NULL,
  `b_time` bigint(40) NOT NULL,
  `b_status` int(1) NOT NULL DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`b_id`, `b_nm`, `b_time`, `b_status`) VALUES
(19, 'Volvo', 1564753667, 1),
(20, 'MARUTI', 1564755442, 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `co_id` int(4) NOT NULL,
  `co_nm` varchar(20) NOT NULL,
  `co_mno` varchar(12) NOT NULL,
  `co_email` varchar(50) NOT NULL,
  `co_msg` longtext NOT NULL,
  `co_time` bigint(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`co_id`, `co_nm`, `co_mno`, `co_email`, `co_msg`, `co_time`) VALUES
(5, 'admin', '9898974526', 'nik@gmail.com', 'tcmh,gjjugv', 1564755637);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `r_id` int(4) NOT NULL,
  `r_nm` varchar(30) NOT NULL,
  `r_age` varchar(2) NOT NULL,
  `r_gender` varchar(10) NOT NULL,
  `r_mno` varchar(12) NOT NULL,
  `r_city` varchar(50) NOT NULL,
  `r_address` varchar(50) NOT NULL,
  `r_email` varchar(40) NOT NULL,
  `r_pwd` varchar(40) NOT NULL,
  `r_time` bigint(40) NOT NULL,
  `r_status` int(1) NOT NULL DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`r_id`, `r_nm`, `r_age`, `r_gender`, `r_mno`, `r_city`, `r_address`, `r_email`, `r_pwd`, `r_time`, `r_status`) VALUES
(13, 'nitin rathod', '21', 'Male', '8965684215', 'rajkot', 'rajkot', 'nik@gmail.com', '123123', 1564754960, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `v_id` int(4) NOT NULL,
  `v_nm` varchar(40) NOT NULL,
  `v_brand` int(1) NOT NULL,
  `v_price` varchar(200) NOT NULL,
  `v_type` varchar(200) NOT NULL,
  `v_des` longtext NOT NULL,
  `v_banner` longtext NOT NULL,
  `v_status` int(11) NOT NULL DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`v_id`, `v_nm`, `v_brand`, `v_price`, `v_type`, `v_des`, `v_banner`, `v_status`) VALUES
(36, 'volvo zeksaa', 19, '300', 'desiel', 'mst che    ', '1564754064_asphalt-auto-automobile-170811.jpg', 1),
(37, 'Swift', 20, '5000', 'Cng', 'rehxjyksyu    ', '1564755506_action-asphalt-auto-981041.jpg', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`ac_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`co_id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`v_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
  MODIFY `ac_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `a_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `b_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `b_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `co_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `r_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `v_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
