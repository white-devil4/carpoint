<?php include('include/header.php');
if(!isset($_SESSION['client']['status']))
{
	header('location:login.php');
}
	?>
	
<div class="container">
	<div class="wrap">
		<div class="content-top">
				<div class="section group">
					<div class="about span_1_of_2">	
						<h3>BOOKINGS</h3>
						<?php
						if(isset($_SESSION['error']))
						{
							echo'<font color="red" >'.$_SESSION['error'].'</font>';
							unset($_SESSION['error']);
						}
						if(isset($_SESSION['success']))
						{
							echo'<font color="green" >'.$_SESSION['success'].'</font>';
							unset($_SESSION['success']);
						}
						?>
						<?php
				$bk=mysqli_query($con,"select * from booking where b_unm='".$_SESSION['client']['uid']."'");
				if(mysqli_num_rows($bk))
				{
					?>
					
					 <table class="table table-hover table table-bordered">
 
						<thead>
						<th>Booking Id</th>
						<th>Vehicle Name</th>
						<th>Brand Name</th>
						<th>No Of Days</th>
						<th>From</th>
						<th>To</th>
						<th>Amount</th>
						<th>cancel</th>
						</thead>
						
						<tbody>
						<?php
						while($bkg=mysqli_fetch_array($bk))
						{
						$qry2=mysqli_query($con,"select * from vehicle,brand where v_brand=b_id and v_id='".$bkg['b_vehicle']."'");
						$vehicle=mysqli_fetch_array($qry2);
							?>
							<tr>
								<td>
									<?php echo $bkg['b_bookid'];?>
								</td>
								<td>
									<?php echo $vehicle['v_nm'];?>
								</td>
								<td>
									<?php echo $vehicle['b_nm'];?>
								</td>
								<td>
									<?php echo $bkg['b_day'];?>
								</td>
								<td>
									<?php echo $bkg['b_sdate'];?>
								</td>
								<td>
									<?php echo $bkg['b_edate'];?>
								</td>
								<td>
									Rs. <?php echo $bkg['b_amt'];?>
								</td>
								<td>
									<?php  if($bkg['b_sdate']<date('d-m-Y'))
									{
										?>
										<i class="glyphicon glyphicon-ok"></i>
										<?php
									}
									else
									{
									echo'<button type="button" class="btn btn-danger"><a href="cancel.php?id='.$bkg['b_bookid'].'">Cancel</button></a>';
									
									
									
									}
									?>
								</td>
							</tr>
							<?php
						}
						?></tbody>
					</table>
					<?php
				}
				else
				{
					?>
					<h3>No Previous Bookings</h3>
					<?php
				}
				?>
					</div>			
				</div>
				<div class="clear"></div>		
			</div>
	</div>
</div>
<?php include('include/footer.php');?>