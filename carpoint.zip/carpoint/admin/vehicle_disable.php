<?php
include("../include/config.php");
session_start();
    if( !empty($_GET))
    {
	session_start();
	$id=$_GET['id'];
	$uq="update  vehicle set v_status=0 where v_id=$id ";
	mysqli_query($con,$uq);
	$_SESSION['disable']="Successfully Disabled";
	header("location:vehicle_manage.php");
	}
	else
	{
	header("location:vehicle.php");
	}

?>