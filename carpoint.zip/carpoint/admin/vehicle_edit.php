<?php
	include("include/header.php");
	include("../include/config.php");
	$id=$_GET['id'];
	$sq="select *  from vehicle where v_id=$id ";
	$res=mysqli_query($con,$sq);
	$row=mysqli_fetch_assoc($res);
?>
<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">vehicle</h1>
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
	<div class="card-header py-3">
	  <h6 class="m-0 font-weight-bold text-primary">Edit Movie</h6>
	</div>
	<div class="card-body">
		<form action="vehicle_editpro.php" method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label>Vehicles Name</label>
				<input type="text" class="form-control" name="vnm" value="<?php echo$row['v_nm']; ?>" required>
			</div>
			<div class="form-group">
				<label>Brand Name</label>
				<select name="brand" class="form-control " required>
			<?php
			$sq="select * from brand,vehicle where b_id=v_brand";
			$b_res=mysqli_query($con,$sq);

			while($b_row=mysqli_fetch_array($b_res))
				{
					echo'<option value="'.$b_row['b_id'].'" selected>'.$b_row['b_nm'].'</option>';
				}
				?>
				</select>
			</div>
			
			 
			<div class="form-group">
				<label>Price Per Day</label>
				<input type="text" class="form-control" name="price" value="<?php echo$row['v_price']; ?>" required>
			</div>
			<div class="form-group">
				<label>Fuel Type</label>
				<input type="text" class="form-control" name="type" value="<?php echo$row['v_type']; ?>" required>
			</div>
			<div class="form-group">
				<label>Description</label>
				<textarea class="form-control" name="des" required><?php echo$row['v_des']; ?>    </textarea>
			</div>

			<div class="form-group">
				<label>Movie Banner</label>
				<img src="../upload/<?php echo$row['v_banner']; ?>" width="90px" height="90px">
				<input type="file" class="form-control" name="banner" value="<?php echo$row['v_banner']; ?>" required>
				
			</div>
			    <input type="hidden" name="id" value ="<?php echo$row['v_id']; ?>" >
			
			<input type="submit" class="btn btn-success" value="Submit">
			<a href="vehicle_disable.php?id=<?php echo$row['v_id']; ?>" class="btn btn-danger">Disable</a>
		</form>
	</div>
  </div>

</div>
<!-- /.container-fluid -->
<?php
	include("include/footer.php");
?>