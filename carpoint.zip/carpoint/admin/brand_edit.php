<?php
	include("include/header.php");
	include("../include/config.php");
	$id=$_GET['id'];
	$sq="select *  from brand where b_id=$id ";
	$res=mysqli_query($con,$sq);
	$row=mysqli_fetch_assoc($res);
?>
<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Brands</h1>
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
	<div class="card-header py-3">
	  <h6 class="m-0 font-weight-bold text-primary">Edit Brande</h6>
	</div>
	<div class="card-body">
		<form action="brand_editpro.php" method="post">
			<div class="form-group">
				<label>Brand Name</label>
				<input type="text" class="form-control" name="bnm" value="<?php echo$row['b_nm']; ?>" required>
			</div>
			 <input type="hidden" name="id" value="<?php echo $row['b_id']; ?>" >
			
			<input type="submit" class="btn btn-success" value="Submit">
			<a href="brand_disable.php?id=<?php echo$row['b_id']; ?>" class="btn btn-danger">Disable</a>
		</form>
	</div>
  </div>

</div>
<!-- /.container-fluid -->
<?php
	include("include/footer.php");
?>