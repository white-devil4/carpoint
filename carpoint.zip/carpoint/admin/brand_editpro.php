<?php
include("../include/config.php");
session_start();
extract($_POST);
    if( !empty($_POST))
    {
	$uq="update  brand set 
b_nm='$bnm' where b_id=$id ";
   
	mysqli_query($con,$uq);
	$_SESSION['update']="Successfully Updated";
	header("location:brand_manage.php");
	}
	else
	{
	header("location:brand.php");
	}

?>