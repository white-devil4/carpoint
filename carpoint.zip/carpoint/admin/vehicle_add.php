<?php
include('../include/config.php');
session_start();
extract($_POST);
extract($_FILES);
$error=array();
if(! empty($_POST))
 {
$sq=mysqli_query($con,"select * from vehicle where v_nm='$vnm' ");
$row=mysqli_fetch_assoc($sq);  
$ext=strtoupper(substr($_FILES['banner']['name'],-4));
    if(!empty($row))
    {
    $error[]="This Vehicle Already Added";
    header("location:vehicle.php");
    }
    else if(empty($_FILES))
    {
    	$error[]="Please Upload Image";
    } 
    else if(!($ext=='.JPG' || $ext=='.PNG'|| $ext=='.GIF' || $ext=='JPEG'))
    {
    $error[]="Upload Proper Image This Type Is Invalid";	
    }
    if(! empty($error))
    {
    $_SESSION['error']=$error;	
    header("location:vehicle.php");
    }
 else{
 	$t=time();
 	$banner=$t.'_'.$_FILES['banner']['name'];
    move_uploaded_file($_FILES['banner']['tmp_name'],'../upload/'.$banner);
	
    $q="insert into vehicle (v_nm,v_brand,v_price,v_type,v_des,v_banner) values ('$vnm','$brand','$price','$type','$des','$banner')";
   $res= mysqli_query($con,$q);
   
    $_SESSION['done']="Successfully Added";
    header("location: vehicle.php");
    }
 }
else
{
header("location: vehicle.php");
}
?>