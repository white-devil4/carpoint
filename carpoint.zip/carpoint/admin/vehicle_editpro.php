<?php
include("../include/config.php");
session_start();
extract($_POST);
extract($_FILES);
$error=array();
$ext=strtoupper(substr($_FILES['banner']['name'],-4));
    if( !empty($_POST))
    {
    	 if(empty($_FILES))
    {
    	$error[]="Please Upload Image";
    } 
    else if(!($ext=='.JPG' || $ext=='.PNG'|| $ext=='.GIF' || $ext=='JPEG'))
    {
    $error[]="Upload Proper Image This Type Is Invalid";	
    }
    else if(! empty($error))
    {
    $_SESSION['error']=$error;	
    header("location:vehicle_edit.php");
    }
    else
    {
    $t=time();
 	$banner=$t.'_'.$_FILES['banner']['name'];
    move_uploaded_file($_FILES['banner']['tmp_name'],'../upload/'.$banner);	
    $uq="update  vehicle set 
v_nm='$vnm',
v_brand='$brand',
v_price='$price',
v_type='$type',
v_des='$des',
v_banner='$banner'
  where v_id=$id ";
	mysqli_query($con,$uq);
	$_SESSION['update']="Successfully Updated";
	header("location:vehicle_manage.php");
	}
}
	else
	{
	header("location:vehicle.php");
	}

?>