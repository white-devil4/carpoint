<?php
	include("include/header.php");
	include("../include/config.php");
	session_start();
?>
<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Booking History</h1>
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
	<div class="card-header py-3">
	  <h6 class="m-0 font-weight-bold text-primary">View History</h6>
	</div>
	<div class="card-body">
		<div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <?php 
       if(isset($_SESSION['del']))
			{
			echo'<font color="red">'.$_SESSION['del'].'</font>';
		unset($_SESSION['del']);
		}
		
			if(isset($_SESSION['update']))
			{
			echo'<font color="green">'.$_SESSION['update'].'</font>';
		unset($_SESSION['update']);
			}
			if(isset($_SESSION['disable']))
			{
			echo'<font color="red">'.$_SESSION['disable'].'</font>';
		unset($_SESSION['disable']);
		}
		if(isset($_SESSION['enable']))
			{
			echo'<font color="green">'.$_SESSION['enable'].'</font>';
		unset($_SESSION['enable']);
		}
?>  
<thead>
                    <tr>
                      <th>No</th>
                      <th>Vehicle</th>
                      <th>Brand Name</th>
                      <th>From</th>
                      <th>To</th>
                      <th>Days</th>
                      <th>Amount</th>
                      <th>Username</th>
                      <th>Mobile No.</th>
                    </tr>
                  </thead>
                  <tbody>
          <?php
  $sq=mysqli_query($con,"select * from booking,vehicle,register where b_vehicle=v_id and b_unm=r_id ");
  $co=1;
while($row=mysqli_fetch_assoc($sq))    	
              {
			$bres=mysqli_query($con,"select * from brand where b_id='".$row['v_brand']."' ");
				  $brow=mysqli_fetch_array($bres);
               echo'<tr>';
               echo'<td>'.$co.'</td>';
               echo'<td>'.$row['v_nm'].'</td>';
               echo'<td>'.$brow['b_nm'].'</td>';
               echo'<td>'.$row['b_sdate'].'</td>';
               echo'<td>'.$row['b_edate'].'</td>';
              echo'<td>'.$row['b_day'].'</td>';
             echo'<td>'.$row['b_amt'].'</td>';
             echo'<td>'.$row['r_nm'].'</td>';
             echo'<td>'.$row['r_mno'].'</td>';
             $co++;
             }
             ?>
                    </tr>
                  </tbody>
                </table>
              </div>
	</div>
  </div>

</div>
<!-- /.container-fluid -->
<?php
	include("include/footer.php");
?>