<?php
include('../include/config.php');
session_start();
$time=time();
extract($_POST);
if(! empty($_POST))
 {
$sq=mysqli_query($con,"select * from brand where b_nm='$bnm' ");
$row=mysqli_fetch_assoc($sq);
    if($bnm==$row['b_nm'])
    {
    $_SESSION['error']="This brand Is Already Exists";
    header("location: brand.php");
    }
    else
    {
    $q="insert into brand (b_nm,b_time) values ('$bnm','$time')";
    mysqli_query($con,$q);
    $_SESSION['done']="Successfully Added";
    header("location: brand.php");
    }
 }
else
{
header("location: brand.php");
}
?>