<?php
	include("include/header.php");
	include("../include/config.php");
?>
<!-- Begin Page Content -->
<div class="container-fluid">
 

 
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Vehicles</h1>
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
	<div class="card-header py-3">
	  <h6 class="m-0 font-weight-bold text-primary">Add New Vehicles</h6>
	</div>
	<div class="card-body">
		<form action="vehicle_add.php" method="post"  enctype="multipart/form-data">
			<?php
			if(isset($_SESSION['done']))
			{
			echo'<font color="green">'.$_SESSION['done'].'</font>';
		unset($_SESSION['done']);
			}
			if(isset($_SESSION['error']))
			{
				foreach($_SESSION['error'] as $er)
				{
				echo'<font color="red">'.$er.'</font>';
				}
				unset($_SESSION['error']);
			}
?>
			<div class="form-group">
				<label>Vehicles Name</label>
				<input type="text" class="form-control" name="vnm" required>
			</div>
			 
			<div class="form-group">
				<label>Brand Name</label>
				<select name="brand" class="form-control " required>
			<?php
			$sq="select * from brand where b_status=1";
			$b_res=mysqli_query($con,$sq);

			while($b_row=mysqli_fetch_array($b_res))
				{
					echo'<option value="'.$b_row['b_id'].'">'.$b_row['b_nm'].'</option>';
				}
				?>
				</select>
			</div>
			<div class="form-group">
				<label>Price Per Day</label>
				<input type="text" class="form-control" name="price" required>
			</div>
			<div class="form-group">
				<label>Fuel Type</label>
				<input type="text" class="form-control" name="type" required>
			</div>
			<div class="form-group">
				<label>Description</label>
				<textarea class="form-control" name="des"></textarea>
			</div>
			<div class="form-group">
				<label>Vehicles Image</label>
				<input type="file" class="form-control" name="banner" required >
			</div>
			<input type="submit"  class="btn btn-success" value="Submit">
		</form>
	</div>
  </div>

</div>
<!-- /.container-fluid -->
<?php
	include("include/footer.php");
?>