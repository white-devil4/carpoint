<?php
session_start();
include('include/config.php');
$id=$_GET['id'];
$t=time();
$name=$_SESSION['client']['nm'];
$cancl=$name. '  Cancellled his booking';
	$uq="insert into activity (ac_nm,ac_time) values('$cancl','$t')";
	mysqli_query($con,$uq);
mysqli_query($con,"delete from booking where b_bookid='$id' ");
header('location:profile.php');
?>