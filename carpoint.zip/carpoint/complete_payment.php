<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php
session_start();
if(!isset($_SESSION['client']['status']))
{
	header('location:login.php');
}
include('include/config.php');
extract($_POST);
$time=time();
if($otp=="123456")
{
    $bookid="BKID".rand(1000000,9999999);
    mysqli_query($con,"insert into booking (b_bookid,b_unm,b_vehicle,b_day,b_amt,b_sdate,b_edate) values('$bookid','".$_SESSION['client']['uid']."','".$_SESSION['vehicle']."','".$_SESSION['day']."','".$_SESSION['amount']."','".$_SESSION['sdate']."','".$_SESSION['edate']."')");
  $amt=$_SESSION['amount'];
  $day=$_SESSION['day'];
  
    $mve=$day.' Booked With '.$amt;
	$uq1="insert into activity (ac_nm,ac_time) values('$mve','$time')";
	mysqli_query($con,$uq1);
    $_SESSION['success']="Booking Successfully Completed";
}
else
{
    $_SESSION['error']="Payment Failed";
}
?>
<body><table align='center'><tr><td><STRONG>Transaction is being processed,</STRONG></td></tr><tr><td><font color='blue'>Please wait <i class="fa fa-spinner fa-pulse fa-fw"></i>
<span class="sr-only"></font></td></tr><tr><td>(Please do not press 'Refresh' or 'Back' button )</td></tr></table><h2>
<script>
    setTimeout(function(){ window.location="profile.php"; }, 5000);
</script>