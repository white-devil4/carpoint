<?php
include ("include/header.php");
$sq="select * from vehicle where v_status=1 ORDER BY v_id DESC LIMIT 4";
$res=mysqli_query($con,$sq);
?>
<div class="now-showing-movies">
		<h3 class="m-head" align="center">CARS</h3>
		<?php
		while($v_row=mysqli_fetch_assoc($res))
		{
			?>
<div class="col-md-3 movie-preview">
			<a href="buynow.php?id=<?php echo$v_row['v_id']; ?>" class="mask">
				<img src="upload/<?php echo $v_row['v_banner'];?>" width="200px" height="200px" class="img zoom-img" alt="" />
				<div class="m-movie-title">
					<a class="m-movie-link" href="buynow.php?id=<?php echo$v_row['v_id']; ?>"><?php echo$v_row['v_nm']; ?></a>
					<div class="clearfix"></div>
					<div class="m-r-date">
						<p><?php echo$v_row['v_date']; ?></p>
						<a href="buynow.php?id=<?php echo$v_row['v_id']; ?>">book now</a>
					</div>
					<div class="m-r-like">
						<i class="fa fa-thumbs-up"></i>
						<p>NEW</p>
					</div>
					 <div class="clearfix"></div>
				</div>
			</a>
		</div>
		<?php
		}
		?>
		 <div class="clearfix"></div>
	</div>		
<?php
		include ('include/footer.php');
		?>