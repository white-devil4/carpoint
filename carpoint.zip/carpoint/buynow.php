<?php include('include/header.php');
$qry2=mysqli_query($con,"select * from vehicle,brand where v_brand=b_id and v_id='".$_GET['id']."' ");
$vehicle=mysqli_fetch_array($qry2);
$id=$_GET['id'];
/*if(!isset($_SESSION['client']['status']))
{
	header("location:login.php");
}*/
?>
<div class="content">
<div class="wrap">
<div class="content-top" style="width:1500px;margin-left:-30px" >
<div class="section group">
<div class="about span_1_of_2">	
<?php

if(isset($_SESSION['error']))
{
	echo'<font color="red">'.$_SESSION['error'].'</font>';
	unset($_SESSION['error']);
}
?>
<center><h3><b><font color="blue">Vehicles Name :<?php echo $vehicle['v_nm']; ?></font></b></h3>	</center>
	<div class="about-top">

		<div class="grid images_3_of_2">
			<img src="upload/<?php echo $vehicle['v_banner']; ?>" width="400px" height="200px"  alt="Banner Not Supported"/>
		</div>
		<div class="desc span_3_of_2">
			<p class="p-link" style="font-size:15px"><b>Price : </b><?php echo $vehicle['v_price']; ?></p>
			<p class="p-link" style="font-size:15px"><b> Brand Name :</b> <?php echo$vehicle['b_nm']; ?></p>
			<p style="font-size:15px"><b>Fual Type :</b> <?php echo $vehicle['v_type']; ?></p>
			<p style="font-size:15px"><b>Description :</b> <?php echo $vehicle['v_des']; ?></p>
			
		</div>
		<div class="clear"></div>
	</div>
	 				
					
					<form action="book.php" method="post">
      <div class="form-group has-feedback">
        <input name="day" type="text" size="25" placeholder="NO OF DAYS" class="form-control"/>
        <input name="id" type="hidden" value="<?php echo $vehicle['v_id']; ?>">

      </div>
     <div class="form-group has-feedback">
        <input name="sdate" type="text" size="25" placeholder="From:  dd-mm-yyyy" class="form-control" />
     
      </div>
	    <div class="form-group has-feedback">
        <input name="edate" type="text" size="25" placeholder="To:  dd-mm-yyyy" class="form-control" />
   
      </div>
      <div class="form-group">
           
		  <button type="submit" class="btn btn-success btn-flat  btn-md">Book Now</button>
 
      </div>
      </div>
</div>
    </form>

</div>			

</div>
<div class="clear"></div>		
</div>
</div>
</div>
<?php include('include/footer.php');?>