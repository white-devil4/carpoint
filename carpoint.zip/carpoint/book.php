<?php include('include/header.php');
extract($_POST);
$avl=array();
if(!isset($_SESSION['client']['status']))
{
	header("location:login.php");
}
$ndate=time();
$date1=strtotime($sdate);
$date2=strtotime($edate);
$diff=($date2-$date1)/(60*60*24);
   if($day!=$diff || $date1<$ndate)
   {
	  $_SESSION['error']="Your Date Is Not Proper Please Enter Real Date";
      header("location:buynow.php?id=$id");	  
   }
$v_res=mysqli_query($con,"select * from vehicle,brand where v_brand=b_id and  v_id=$id");
	$v_row=mysqli_fetch_assoc($v_res);
	?>
<div class="content">
	<div class="wrap">
		<div class="content-top" style="width:1000px;margin-left:-10px" >
			<div class="container"style="width:1500px;margin:-40px"    >
				 
  <div class="col-md-12">
				<div class="section group">
					<div class="about span_1_of_2">	
					<center><h3>Vehicle Name : <?php echo $v_row['v_nm']; ?></h3>	</center>
							<div class="about-top">	
								<div class="grid images_3_of_2">
									<img src="upload/<?php echo $v_row['v_banner']; ?>" alt=""/>
								</div>
								<div class="desc span_3_of_2">
									<p class="p-link" style="font-size:15px;margin-left:10px"><b>Price : </b><?php echo $v_row['v_price']; ?></p>
									<p class="p-link" style="font-size:15px;margin-left:10px"><b>Brand Name  : </b><?php echo $v_row['b_nm']; ?></p>
								</div>
								<div class="clear"></div>
							</div>
							<table class="table table-hover table-bordered text-center">
								<tr>
											<td>
												Vehicle Name
											</td>
										<td>
											<?php 
												
												echo $v_row['v_nm'];

?>
										</td>
									</tr>
									<tr>
										<td>
											From Date :
										</td>
										<td>
						<?php 
								echo$sdate;
							?>
						
										</td>
									</tr>
									<tr>
										<td>
											To Date:
										</td>
										<td>
											<?php echo $edate;?>
										</td>
									</tr>
									<tr>
										<td>
											Number of Days
										</td>
										<td>
										<?php echo $day;
										?>
											<form  action="process_booking.php" method="post">
											<input type="hidden" name="vehicle" value="<?php echo $v_row['v_id'];?>"/>					
											<input type="hidden" name="day" value="<?php echo $day;?>"/>					
											<input type="hidden" name="amount" value="<?php echo $v_row['v_price']*$day;?>"/>
											<input type="hidden" name="sdate" value="<?php echo $sdate;?>"/>
											<input type="hidden" name="edate" value="<?php echo $edate;?>"/>
										</td>
									</tr>
									<tr>
										<td>
											Amount
										</td>
										<td id="amount" style="font-weight:bold;font-size:18px">
											Rs <?php echo $v_row['v_price']*$day;?>
										</td>
									</tr>
									<tr>
										<td colspan="2">
										<button class="btn btn-success btn-md" style="width:100%">Book Now</button>
										 
										</form></td>
									</tr>
						<table>
							<tr>
								<td></td>
							</tr>
						</table>
					</div>			
				
			</div>
				<div class="clear"></div>		
			</div>
	</div>
	</div>
</div>
<?php include('include/footer.php');?>