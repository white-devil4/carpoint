<?php include("include/header.php"); 
$sq="select * from vehicle";
$res=mysqli_query($con,$sq);
?>
	
<div class="now-showing-movies">
		<h3 class="m-head"> NEW CARS</h3>
		<?php
											while($v=mysqli_fetch_assoc($res))
											{
												
												?>
<div class="col-md-3 movie-preview">
			<a href="buynow.php?id=<?php echo$v['v_id']; ?>" class="mask">
				<img src="upload/<?php echo $v['v_banner'];?>" class="img-responsive zoom-img" alt="" />
				<div class="m-movie-title">
					<a class="m-movie-link" href="buynow.php?id=<?php echo$v['v_id']; ?>"><?php echo$v['v_nm']; ?></a>
					<div class="clearfix"></div>
					<div class="m-r-date">
						<p><i class="fa fa-calendar-o"></i></p>
						<a href="buynow.php?id=<?php echo$v['v_id']; ?>">book now</a>
					</div>
					 
				</div>
			</a>
		</div>
		<?php
		}
		?>
		 <div class="clearfix"></div>
	</div>
	 <?php include ("include/footer.php"); ?>