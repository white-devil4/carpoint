<?php
    $host = "localhost";
    $user = "root";      
    $pass = "";            
    $db = "carpoint";
    $port = 3306;
     $con = mysqli_connect($host, $user, $pass, $db, $port);
?>