<div class="copy-rights text-center">
	<p>&copy; 2019 Car Rental Point. All Rights Reserved | Design by <a href="">RATHOD NITIN</a></p>
</div>
</body>
</html>